/**
 * asciinema-player v2.6.1
 *
 * Copyright 2011-2018, Marcin Kulik
 *
 */
